# 🌳 chinese-path-reader 使用示例

## 示例 1：读取单个文件

```powershell
# 方法 1：直接读取
$content = Read-ChinesePath -Path "C:\Users\23883\Desktop\CC 指南\文件.md"
Write-Host $content

# 方法 2：万能模板（3 行代码）
$desktop = [Environment]::GetFolderPath("Desktop")
$folder = (Get-ChildItem $desktop -Directory | Where-Object { $_.Name -like "*CC*" }).FullName
$content = [System.IO.File]::ReadAllText("$folder\文件.md", [System.Text.Encoding]::UTF8)
Write-Host $content
```

---

## 示例 2：读取桌面文件夹

```powershell
# 步骤 1：获取桌面路径
$desktop = Get-DesktopPath
Write-Host "桌面路径：$desktop"

# 步骤 2：查找 CC 文件夹
$ccFolder = Find-DesktopFolder -Keyword "CC"
Write-Host "CC 文件夹：$ccFolder"

# 步骤 3：读取文件
$content = Read-ChinesePath -Path "$ccFolder\CC 权限配置.md"
Write-Host $content
```

---

## 示例 3：读取多个文件

```powershell
# 步骤 1：获取文件列表
$files = Get-ChineseFiles -Path "C:\Users\23883\Desktop\CC 指南"

# 步骤 2：逐个读取
foreach ($file in $files) {
    Write-Host "=== $file ===" -ForegroundColor Cyan
    $content = Read-ChinesePath -Path $file
    Write-Host $content
    Write-Host ""
}
```

---

## 示例 4：模糊匹配文件夹

```powershell
# 查找包含"指南"的文件夹
$folder = Find-DesktopFolder -Keyword "指南"
Write-Host "找到文件夹：$folder"

# 查找包含"CC"的文件夹
$folder = Find-DesktopFolder -Keyword "CC"
Write-Host "找到文件夹：$folder"
```

---

## 核心要点

1. **使用 .NET 方法** - `[System.IO.File]::ReadAllText()`
2. **指定 UTF8 编码** - `[System.Text.Encoding]::UTF8`
3. **不要用 PowerShell 原生命令** - `Get-Content` 会失败
4. **3 行代码搞定** - 万能模板可以直接复制

---

_3 行代码搞定中文路径读取！_ 🌳
