# 🌳 chinese-path-reader 安装脚本

Write-Host "================================" -ForegroundColor Green
Write-Host "🌳 中文路径读取 Skill 安装程序" -ForegroundColor Green
Write-Host "================================" -ForegroundColor Green
Write-Host ""

# 获取脚本所在目录
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$skillSource = $scriptDir
$skillTarget = "$env:USERPROFILE\.openclaw\skills\chinese-path-reader"

Write-Host "📂 源目录：$skillSource" -ForegroundColor Cyan
Write-Host "📂 目标目录：$skillTarget" -ForegroundColor Cyan
Write-Host ""

# 检查源目录是否存在
if (!(Test-Path $skillSource)) {
    Write-Host "❌ 错误：源目录不存在！$skillSource" -ForegroundColor Red
    exit 1
}

# 创建目标目录
if (!(Test-Path $skillTarget)) {
    New-Item -ItemType Directory -Path $skillTarget -Force | Out-Null
    Write-Host "✅ 已创建目标目录" -ForegroundColor Green
}

# 复制文件
Write-Host "📦 正在复制文件..." -ForegroundColor Yellow
Copy-Item "$skillSource\*" -Destination $skillTarget -Recurse -Force
Write-Host "✅ 文件复制完成" -ForegroundColor Green

Write-Host ""
Write-Host "================================" -ForegroundColor Green
Write-Host "✅ 安装完成！" -ForegroundColor Green
Write-Host "================================" -ForegroundColor Green
Write-Host ""
Write-Host "使用方法：" -ForegroundColor Cyan
Write-Host "  Read-ChinesePath -Path `"文件路径`"" -ForegroundColor Yellow
Write-Host "  Get-ChineseFiles -Path `"文件夹路径`"" -ForegroundColor Yellow
Write-Host "  Get-DesktopPath" -ForegroundColor Yellow
Write-Host "  Find-DesktopFolder -Keyword `"关键词`"" -ForegroundColor Yellow
Write-Host ""
Write-Host "重启 OpenClaw 后即可使用！" -ForegroundColor Green
Write-Host ""
